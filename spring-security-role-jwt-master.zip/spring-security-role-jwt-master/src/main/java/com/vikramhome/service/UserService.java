package com.vikramhome.service;

import com.vikramhome.model.User;
import com.vikramhome.model.UserDto;
import com.vikramhome.model.UserToken;

import java.util.List;

public interface UserService {
    User save(UserDto user);
    List<User> findAll();
    User findOne(String username);
    List<UserToken> save(List<UserToken> userTokens);
    List<UserToken> findList(long userId);
}
