package com.vikramhome.dao;

import java.util.List;
import com.vikramhome.model.UserToken;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserTokenDao extends CrudRepository<UserToken, Long> {
    List<UserToken> findByUserid(long userid);
}