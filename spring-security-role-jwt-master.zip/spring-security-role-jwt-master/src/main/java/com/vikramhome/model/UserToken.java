package com.vikramhome.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserToken {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long utkid;

    @Column
    private String token;

    @Column
    private long userid;

    @Column
    private String active;

    public long getUtkid() {
        return utkid;
    }

    public void setUtkid(long utkid) {
        this.utkid = utkid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }
}